# CS1300 Fall 2017
# Author: Bryce DesBrisay
# Recitation: 210 Arcadia
# Assignment 10


#PART_1 functions here

def read_books(fileName):
    # Reads lines from file and separated them into lists and appends it to a book list
    books = []

    try:
        file = open(fileName, 'r', encoding='utf-8')
        for line in file:
            bookInfo = line.rstrip().split(',')
            books.append([bookInfo[1], bookInfo[0]])

        return books
    except:
        return None


def read_users(user_file):
    # Reads lines from file and creates a dict with the name as a key and ratings as values
    users = {}

    try:
        file = open(user_file, 'r', encoding='utf-8')
        for line in file:
            ratings = line.rstrip().split(' ')
            users[ratings[0]] = ratings[1:]

        return users
    except:
        return None


def calc_avg_rating(ratings_dict):
    # Calculates the average rating for every book and returns a list of them
    avgs = []

    for item in ratings_dict:
        total = 0.0
        index = 0

        for rating in ratings_dict[item]:
            if float(rating) != 0:
                total += float(rating)
                index += 1

        avgs.append(total / index)

    return avgs


def lookup_avg_rating(index, book_dict, avg_ratings_dict):
    # Returns string with the average rating, book name, and book author
    return '(' + str(avg_ratings_dict[index]) + ')' + ' ' + book_dict[index][0] + ' by ' + book_dict[index][1]

#PART_2 follow here
'''
class Recommender:
    #Constructor here
    def __init__(self, book_filename, ratings_filename):
        self.read_books(book_filename)
        self.read_users(ratings_filename)
        self.book_list = []
        self.user_dictionary = {}
        self.average_ratings_list = []

    def read_books(self, fileName):
        # Reads lines from file and separated them into lists and appends it to a book list
        try:
            file = open(fileName, 'r', encoding='utf-8')
            for line in file:
                bookInfo = line.rstrip().split(',')
                book_list.append([bookInfo[1], bookInfo[0]])

        except:
            return None


    def read_users(self, fileName):
        # Reads lines from file and creates a dict with the name as a key and ratings as values
        try:
            file = open(fileName, 'r', encoding='utf-8')
            for line in file:
                ratings = line.rstrip().split(' ')
                user_dictionary[ratings[0]] = ratings[1:]

        except:
            return None


    def calc_avg_rating(self):
        # Calculates the average rating for every book and returns a list of them
        for item in user_dictionary:
            total = 0.0
            index = 0

            for rating in user_dictionary[item]:
                if float(rating) != 0:
                    total += float(rating)
                    index += 1

            average_ratings_list.append(total / index)


    def lookup_avg_rating(self, index):
        # Returns string with the average rating, book name, and book author
        return '(' + str(average_ratings_list[index]) + ')' + ' ' + books_list[index][0] + ' by ' + books_list[index][1]

	def calc_similarity(self, user1, user2):
		return similarity_measure

	def get_most_similar_user(self, current_user_id):
		return best_user_match_id

	def recommend_books(self, current_user_id):
		return recommendations_list
'''


def main():
    #test your functions and classes here

    '''
    books = read_books("book.txt")
    print(books[0])

    users = read_users("ratings.txt")
    print(users["Tony"])

    print(calc_avg_rating(users))

    print(lookup_avg_rating(0, books, calc_avg_rating(users)))
    ' ''

    rec = Recommender("book.txt", "ratings.txt")

    print(rec.book_list)

    '''



if __name__ == "__main__":
    main()

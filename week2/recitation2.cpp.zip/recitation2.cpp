#include <iostream>

using namespace std;

int main() {
  cout<<"Hello, CS1300 World!";
}
